package com.qualcomm.ftccommon;

public abstract interface Restarter
{
  public abstract void requestRestart();
}


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\Restarter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */