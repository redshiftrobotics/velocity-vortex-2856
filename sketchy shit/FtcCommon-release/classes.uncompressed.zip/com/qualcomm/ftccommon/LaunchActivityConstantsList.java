package com.qualcomm.ftccommon;

public class LaunchActivityConstantsList
{
  public static final String ZTE_WIFI_CHANNEL_EDITOR_PACKAGE = "com.zte.wifichanneleditor";
  public static final String VIEW_LOGS_ACTIVITY_FILENAME = "Filename";
  public static final int FTC_ROBOT_CONTROLLER_ACTIVITY_CONFIGURE_ROBOT = 3;
}


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\LaunchActivityConstantsList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */