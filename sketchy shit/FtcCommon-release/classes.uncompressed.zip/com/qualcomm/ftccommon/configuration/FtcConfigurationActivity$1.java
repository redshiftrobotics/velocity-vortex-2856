package com.qualcomm.ftccommon.configuration;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class FtcConfigurationActivity$1
  implements DialogInterface.OnClickListener
{
  FtcConfigurationActivity$1(FtcConfigurationActivity paramFtcConfigurationActivity) {}
  
  public void onClick(DialogInterface dialog, int button) {}
}


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\configuration\FtcConfigurationActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */