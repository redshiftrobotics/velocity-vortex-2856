/*    */ package com.qualcomm.ftccommon;
/*    */ 
/*    */ import android.content.Intent;
/*    */ import android.preference.Preference;
/*    */ import android.preference.Preference.OnPreferenceClickListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FtcRobotControllerSettingsActivity$SettingsFragment$3
/*    */   implements Preference.OnPreferenceClickListener
/*    */ {
/*    */   FtcRobotControllerSettingsActivity$SettingsFragment$3(FtcRobotControllerSettingsActivity.SettingsFragment paramSettingsFragment) {}
/*    */   
/*    */   public boolean onPreferenceClick(Preference preference)
/*    */   {
/* 90 */     Intent localIntent = new Intent("android.settings.SETTINGS");
/* 91 */     this.a.startActivity(localIntent);
/*    */     
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\FtcRobotControllerSettingsActivity$SettingsFragment$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */