package com.qualcomm.ftccommon;

public class Device
{
  public static final String MODEL_FOXDA_FL7007 = "FL7007";
  public static final String MANUFACTURER_ZTE = "zte";
  public static final String MODEL_ZTE_SPEED = "N9130";
}


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\Device.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */