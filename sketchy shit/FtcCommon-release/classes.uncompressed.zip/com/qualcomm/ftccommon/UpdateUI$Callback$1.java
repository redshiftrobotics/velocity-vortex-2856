/*    */ package com.qualcomm.ftccommon;
/*    */ 
/*    */ import android.widget.Toast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UpdateUI$Callback$1
/*    */   implements Runnable
/*    */ {
/*    */   UpdateUI$Callback$1(UpdateUI.Callback paramCallback) {}
/*    */   
/*    */   public void run()
/*    */   {
/* 56 */     Toast.makeText(this.a.a.c, "Restarting Robot", 0).show();
/*    */   }
/*    */ }


/* Location:              C:\Users\SAAS Student\Documents\Robotics\2856\sketchy shit\FtcCommon-release\classes.zip!\com\qualcomm\ftccommon\UpdateUI$Callback$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */